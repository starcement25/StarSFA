package com.forcepower.acedns.constants;


import com.anychart.core.Base;

public class AceDnsWebServiceURL {
     public static String parentURL = BaseUrl.baseUrl;
     public static String devUrl = BaseUrl.baseUrl;
    public static String sbBashUrl = BaseUrl.sbDevUrl;

    // SB Infowaves
    // Dealer Declaration
    public static String declarationListUrl = "api_get_dealer_req_list.php";
    public static String declarationApproveRejectUrl = "api_approve_reject_dealer_exclusive.php";
    // Site Lead
    public static String siteDataList = "misreport/api_get_fetch_site_data.php";
    public static String routeNameEmployeeWise ="misreport/api_get_route_name_employee.php";
    public static String routeNameCustomerWise="misreport/api_get_route_using_phone.php";
    public static String siteDetails="misreport/api_get_site_details.php";
    public static String meetUpPerson="misreport/api_get_meet_up_person.php";
    public static String branchList="misreport/api_get_branch.php";
    public static String stateList="misreport/api_get_state_details.php";
    public static String districtList="misreport/api_get_district_name.php";
    public static String siteSegment="misreport/api_site_segment.php";
    public static String projectSegment="misreport/api_get_project_segment.php";
    public static String constructionType="misreport/api_get_type_of_construction.php";
    public static String constructionCurrentStage="misreport/api_get_current_stage_of_construction.php";
    public static String otherCementBrand="misreport/api_get_cement_brand_used.php";
    public static String decisionMaker="misreport/api_get_decision_maker.php";
    public static String productDemo="misreport/api_get_product_demo.php";
    public static String visitType="misreport/api_get_visit_type.php";
    public static String visitTypeStar="misreport/api_get_visit_type_star.php";
    public static String visitTypeNonStar="misreport/api_get_visit_type_nonstar.php";
    public static String rssdList="misreport/api_get_list_of_rssd.php";
    public static String approvedByList="misreport/api_get_approved_by.php";
    public static String siteFormSubmit="misreport/api_submit_site_form.php";
    public static String khojCount="misreport/api_get_count_site_visit_employee.php";
    public static String khojDetails="misreport/api_get_list_site_visit.php";


    /* SETUP URLbbb
     * IMAGE LOGO URL
     */
    public static String databaseDetailsURL = "table-structure-details-6.0.2.php";
    public static String checkNickNameURL = "user-details-incremental-6.0.9.php";
    public static String downloadLogoURL1 = "logo-download-6.0.0.php";
    public static String updateFireBaseRegistrationIdUrl = "updateRegistrationId-6.0.0.php";

    /*
     * AUTHENTICATION URLs
     */
    public static String employeeDetailsOldLoginURL = "emplogin-check-6.0.0.php";
    public static String employeeDetailsLoginURL = "emplogin-check-6.0.1.php";
    public static String employeeDetailsLoginMobileURL = "emplogin-check-phno-6.0.1.php";
    public static String updateDeviceIdURL = "updateDeviceId-6.0.1.php";
    public static String phnoeNumberValidationURL = "phoneno-validation.php";
    public static String OTPValidationURL = "generateOTP.php";

    //////Star SFA///////
    public static String updateCheckURL = "updateApp-6.0.2_play_7.php";
    public static String updateCheckURL_db = "updateAppDB-6.0.2.php";
    public static String dbBackUpCheckURL = "dbbackupcheck-6.0.0.php";
    public static String dbBackUpSubmitURL = "movedb-6.0.0.php";
    public static String downloadDictionaryURL = "datadownloaddictionary-7.0.6.php";
    public static String dbDeleteURL = "dbdeletecheck-6.0.0.php";
    public static String confirmDownloadURL = "updateFirstloginDatetime-6.0.2.php";
    public static String createDCRURL = "createDCR.php";
    public static String transactionToDeleteURL = "transaction-to-delete-6.0.0.php";
    public static String transactionDeletionConfirmationURL = "transactionDeletionConfirmation-6.0.0.php";
    /*
     * SETUP TABLE URLs
     */
    public static String surveyFormDetailsURL = "survey-form-details-incremental-6.1.3.php";
    public static String saudaFormDetailsURL = "sauda-form-details-incremental-6.0.5.php";
    public static String menuDetailsURL = "menu-details-incremental-8.5.3.php";
    public static String marketFeedbackDetailsURL = "market-feedback-details-incremental-6.0.6.php";
    public static String marketFeedbackTaggingDetails = "market-feedback-tagging-details-6.0.1.php";
    public static String vendorDetailsDownload = "vendor-details-download.php";
    public static String userDetailsURL = "user-details-incremental-8.0.0.php";
    public static String orderFormDetailsURL = "order-form-details-incremental-7.2.0.php";
    public static String productDetailsURL = "setup-product-details-incremental-6.0.8.php";
    public static String routePlanDetailsURL = "route-plan-details-incremental-6.0.5.php";
    public static String selfAppraisalDetails = "self-appraisal-details-incremental-6.0.2.php";
    public static String targetAchievementDetailsRouteWise = "target-achievement-txt-route-categorywise-6.0.0.php";

    /*
     *  MASTER TABLE URLs
     */
    public static String surveyTableViewURL = "table_view_details-6.0.1-mle.php";//20dec star mle testing
    public static String destinationMasterURL = "destination-master-txt-6.0.1.php";
    public static String branchWiseSchemePdfDownloadMasterURL = "branchwise-scheme-download-txt-6.0.1.php";
    public static String SchemePdfDownloadMasterURL = "scheme-PDF-download-txt-6.0.1.php";
    public static String branchWiseGoldenRuleURL = "branchwise-goldenrules-download-txt-6.0.0.php";
    public static String salesPerformanceURL = "sale-performance-details-txt-6.0.1.php";
    public static String saudaMrpURL = "sauda-mrp-txt-incremental-6.0.3.php";
    public static String bargainMrpURL = "bargain-rate-txt-incremental-6.0.0.php";
    public static String grnDoDownloadURL = "GRN-DO-download.php";
    public static String customerProductRelationURL = "customer-product-relation-txt-6.0.3.php";
    public static String mcxRateIncrementalURL = "mcx-rate-txt-incremental-6.0.0.php";
    public static String OrderApprovalIncrementalURL = "order-approval-details-incremental-6.0.2.php";
    public static String BranchDestinationIncrementalURL = "branch-destination-incremental-6.0.0.php";
    public static String BranchDumpIncrementalURL = "branch-dump-incremental-6.0.0.php";
    public static String customerBrokerRelationURL = "customer-broker-relational-txt-incremental-6.0.2.php";
    public static String BrokerageCostURL = "brokerage-cost-txt-incremental-6.0.1.php";
    public static String depotCostURL = "depot-cost-txt-incremental-6.0.0.php";
    public static String bargainTransactionURL = "bargain-transaction-download-6.0.2.php";
    public static String bargainReportDataDownloadModeWiseURL = "bargain-downlod-mode-wise-6.0.0.php";
    public static String doReportDataDownloadModeWiseURL = "DO-transaction-download-mode-wise-6.0.0.php";
    public static String bargainReportDataDownloadModeWiseSaudaListURL = "bargain-downlod-mode-saudano-wise-6.0.0.php";
    public static String doReportDataDownloadModeWiseSaudaListURL = "DO-download-mode-dono-wise-6.0.0.php";
    public static String bargainReportDataDownloadModeWiseSaudaListWithDetailsURL = "bargain-downlod-mode-sku-wise-6.0.0.php";
    public static String doReportDataDownloadModeWiseSaudaListWithDetailsURL = "DO-downlod-mode-sku-wise-6.0.0.php";
    public static String primaryFreightURL = "primary-freight-txt-incremental-6.0.0.php";
    public static String mallSurveyRelationURL = "mall-survey-relation.php";
    public static String mallMasterURL = "mall_master_api_6.0.1.php";
    public static String selfAppraisalCustomerWise = "target-achievement-txt-customerwise-6.0.2.php";
    public static String selfAppraisalEmpWise = "target-achievement-txt-empwise-6.0.0.php";
    public static String desingnationWiseTATDLimitUrl = "designation-wise-TA-DA-limit-txt-6.0.0.php";
    public static String empTargetAcheivementURL = "emp-target-achievement-txt-6.0.2.php";
    public static String empDateWiseRouteAllocationURL = "emp-datewise-route-allocation-txt.php";
    public static String pendingContractURL = "pending-contract-ageing-txt-6.0.1.php";
    public static String menuAccessURL = "menu-access-txt-6.0.1.php";
    public static String employeemenuAccessURL = "emp-menu-access-txt-6.0.0.php";
    public static String genericOilDetailsURL = "generic-oil-master.php";
    public static String BoqMasterURL = "BOQ-master-6.0.2.php";
    public static String AdditionalMaterialURL = "additional-material.php";
    public static String weekwiseTargetAchievementDetailsURL = "emp-week-wise-target-achievement-txt.php";
    public static String prospectiveCustomerDetailsURL = "prospective_customer_master_6.0.1.php";
    public static String surveyInputDetailsURL = "survey_input_details-6.0.9-mletest.php";
    public static String surveyCategoryDetailsURL = "surveycategory_master-tx_incremental.php";
    public static String previousOrderCountingURL = "prev-order-counting-master-txt-incremental-6.0.0.php";
    public static String farmerMasterDownloadURL = "farmer-master-txt-incremental-6.0.2.php";
    public static String orderStatusURL = "order-status-incremental-6.0.3.php";
    public static String brokerDetailsURL = "broker-master-txt-incremental-6.0.1.php";
    public static String nonTradeCustomerURL = "non-trade-customer-master-incremental.php";
    public static String routeCustomerPlanDetailsURL = "route-customer-plan-master-txt-6.0.0.php";
    public static String branchRouteFreightDetailsURL = "branch-route-freight-txt-6.0.4.php";
    public static String loadDistributionDetailsURL = "load-distribution-txt-incremental-6.0.1.php";
    public static String outstandingAgeingURL = "outstanding-ageing-txt.php";
    public static String saudaTransactionLogURL = "sauda-transaction-log-txt-6.0.1.php";
    public static String saudaAllocationLogURL = "sauda-allocation-log-txt-incremental.php";
    public static String masterStreetLogURL = "street-master-incremental.php";
    public static String routeDetailsURL = "route-txt-incremental-6.0.6.php";
    public static String routeDetailsAlternateURL = "route-allocation-txt-6.0.0.php";
    public static String distributorRouteDetailsURL = "distributor-route-incremental-6.0.3.php";
    public static String customerToDeleteURL = "customer-to-delete-6.0.0.php";
    public static String customerDeleteConfirmationURL = "customer-deletion-confirm.php";
    public static String customerDetailsURL = "customer-master-audit-txt-incremental-9.0.0.php";
    public static String customerAlternateUrlForCrm = "customer-master-allocation-txt-6.0.0.php";
    public static String customerProductMsl = "customer-product-msl-6.0.0.php";
    public static String creditLimitURL = "customer-master-credit-limit-incremental-6.0.0.php";
    public static String outstandingDetailsURL = "outstanding-txt-incremental-6.0.1.php";
    public static String productGroupDetailsURL = "product-group-master-txt-incremental-6.0.2.php";
    public static String productSubGroupDetailsURL = "product-sub-group-master-txt-incremental-6.0.1.php";
    public static String productBrandDetailsURL = "product-brand-master-txt-incremental-6.0.1.php";
    public static String productMasterDetailsURL = "product-master-txt-incremental-7.0.5.php";
    public static String catSubcatBrandMappingURL = "cat-subcat-brand-mapping-txt-incremental.php";
    public static String catSubcatProdMappingURL = "cat-subcat-prod-mapping-txt-incremental.php";
    public static String InvoiceInformationDownloadURL = "invoice-txt-information-6.0.0.php";
    public static String closingStockURL = "product-cl-stk-txt-incremental-6.0.0.php";
    public static String vanSalesStockAllocationURL = "van-stock-allocation-txt-6.0.0.php";
    public static String mrpURL = "mrp-txt-incremental-6.0.5.php";
    public static String beatWiseTADADownload = "beatwise-TA-DA-txt-6.0.0.php";
    public static String retailerWiseTargetAchievement = "retailer-wise-target-ach-txt-6.0.0.php";
    public static String branchWiseTargetAchievement = "branch-wise-target-achievement-txt.php";
    public static String productGroupWiseTargetAchievement = "productgroup-wise-target-achievement-txt.php";
    public static String yellowCardValidationDate = "yellow-card-date-validation-txt-6.0.1.php";
    public static String yellowCardValidationDateCustomerWise = "yellow-card-date-validation-txt-6.0.2.php";
    public static String CustomerProductWiseOrderPlan = "cust-product-wise-orderplan.php";
    public static String stateDistrictTownTableUrl = "state-district-town-txt.php";
    public static String catalogueDownloaderUrl = "catalogue-txt-incremental-6.0.0.php";
    public static String facilitatorMasterDownloaderUrl = "facilitator-master-txt-incremental-6.0.4.php";
    public static String siteMasterDownloaderUrl = "site-master-txt-incremental-6.0.9.php";
    public static String stateMasterUrl = "state-master-txt-6.0.0.php";

    public static String surveyPublishURL = "survey-publish-download-6.0.1.php";
    public static String offerPublishURL = "offer-publish-download-6.0.0.php";
    public static String fssurveyPublishURL = "fs-survey-publish-download.php";
    public static String prevStockCountingURL = "prev-stock-counting-master-txt-incremental-6.0.0.php";
    public static String prodQtyCustClassWiseTD = "prodqty-custclass-wise-TD-txt.php";
    public static String routePlanURL = "route-plan-master-txt-6.0.5.php";
    public static String travelExpCategoryURL = "transport-mode-category-txt-6.0.0.php";
    public static String travelExpSubCategoryURL = "transport-mode-sub-category-txt-6.0.0.php";
    public static String bankURL = "bank-list-txt-incremental-6.0.0.php";
    public static String attendanceReportURL = "attendance-checkout-txt-incremental-6.0.0.php";
    public static String managerActivityUrl = "manager-activity-download-6.0.2.php";
    public static String managerActivityOnClickUrl = "manager-activity-api.php";
    public static String loyaltyCustomerURL = "loyalty-card-holder-txt-6.0.0.php";
    public static String rdsMasterURL = "rds-master-txt-incremental-6.0.1.php";
    public static String otherEmployeeURL = "emp-master-txt-7.0.1.php";
    public static String cashTransferMasterURL = "cash-transaction-download-incremental-6.0.0.php";
    public static String branchURL = "branch-master-txt-6.0.5.php";
    public static String honeyCombURL = "honeycomb-cost-txt-incremental-6.0.2.php";
    public static String marginCostURL = "margin-cost-txt-incremental-6.0.1.php";
    public static String vendorURL = "vendor-master-txt-6.0.0.php";
    public static String gitURL = "git-master-txt-incremental-6.0.0.php";
    public static String misTransactionLogURL = "mis-transaction-log-txt-6.0.0.php";
    public static String capMasterURL = "scheme-txt-6.0.0.php";
    public static String loyaltyPurchaseURL = "loyalty-purchase-details-txt-6.0.1.php";
    public static String redeemPointURL = "redeem_award_master_incremental.php";
    public static String userAccessURL = "user-access-txt-6.0.0.php";
    public static String saudaURL = "sauda-allocation-txt-6.0.1.php";
    public static String TDAllocationURL = "TD-allocation-txt-6.0.0.php";
    public static String saudaAllocationAccessURL = "sauda-allocation-access.php";
    public static String TDAllocationAccessURL = "TD-allocation-access.php";
    public static String custBranchURL = "customer-branch-relational-txt-incremental-6.0.1.php";
    public static String sampleDownloadURL = "sample-txt-incremental-6.0.0.php";
    public static String loyaltyCardTransactionURL = "loyalty-card-transaction-details-txt-5.1.3.php";
    public static String competitorGroupURL = "competitor-group-master-s-6.0.5.php";//""competitor-group-master-6.0.4.php";
    public static String branchWiseGeoFencingURL = "branchwise-geo-fencing-download-6.0.1.php";
    public static String schemeMasterURL = "scheme-txt-6.0.2.php";
    public static String freebieMasterURL = "freebies-master-txt-6.0.1.php";
    public static String stockAllocationURL = "stock-allocation-txt-6.0.0.php";
    public static String stockBalanceURL = "stock-balance-txt-6.0.0.php";
    public static String zeroOutletDetailsUrl = "zerooutlet-6.0.0.php";
    public static String splashScreenDetailsUrl = "splash-screen-details-6.0.0.php";
    public static String billingInformationURL = "billing-information-txt-6.0.2.php";
    public static String orderSummaryURL = "order-summary-txt-6.0.0.php";
    public static String dealerTransactionURL = "dealer-transaction-txt-6.0.0.php";
    public static String imeiStatusURL = "IMEIstatus-6.0.0.php";
    public static String conversionDataDownloadURL = "conversion-data-download-6.0.1.php";
    public static String customerProductInfoURL = "customer-product-info-txt.6.0.1.php";
    public static String customerProposedProductURL = "customer-proposed-product-txt.6.0.0.php";
    public static String GiftMasterDownloadURL = "gift-master-txt-download-6.0.0.php";
    public static String TechnicalMeetApprovalURL = "tech-meet-approval-details-6.0.0.php";
    public static String TechnicalMeetApprovalDetailsURL = "tech-meet-approval-meeting-details-6.0.0.php";

    /*
     * TRANSACTION URLs
     */

    public static String submitEditedCustomer = "operationdb-updatecustomer-6.0.0.php";
    public static String submitSaudaAllocation = "operationdb-sauda-allocation.php";//STAR MISSING
    public static String submitTDAllocation = "operationdb-TD-allocation.php";//STAR MISSING
    public static String submitFeedBackURL = "operationdb-market-feedback-6.0.2.php";//""operationdb-market-feedback.php";
    public static String submitSamplingURL = "operationdb-product-promotion.php";
    public static String submitWholeSaleURL = "operationdb-wholesaler-details.php";
    public static String submitSurveyURL = "operationdb-survey-7.0.2_mle.php";
    public static String submitSurveyHeaderURL = "operationdb-no-survey.php";
    public static String submitSurveyPublishURL = "operationdb-survey-audit-6.0.0.php";
    public static String submitOfferSurveyURL = "operationdb-offers-6.0.0.php";
    public static String submitSaudaURL = "operationdb-sauda-6.0.9.php";
    public static String submitMarketFeedbackStock = "operationdb-market-feedback-stockaudit-sa-6.0.2.php";//""operationdb-market-feedback-stockaudit-6.0.1.php";
    public static String submitTransactionURL = "operationdb-transaction-7.0.8.php";
    public static String submitTransactionURLForScheme = "operatiodb-scheme-6.0.1.php";
    public static String submitTransactionSpecialURL = "operationdb-transaction-special.php";//for SPA price validation type only
    public static String submitQuotationTransactionURL = "operationdb-quotation.php";
    public static String submitRequisitionDetailsTransactionURL = "operationdb-requisition-details.php";
    public static String submitCollectionForecastTransactionURL = "operationdb-collection-forecast.php";
    public static String submitGrnTransactionURL = "operationdb-GRN-upload.php";
    public static String submitOrderEditTransactionURL = "operationdb-order-edit.php";
    public static String submitStockAuditEditTransactionURL = "operationdb-stock-audit-edit.php";
    public static String submitStockReallocationTransactionURL = "opeartiondb-stock-reallocation.php";
    public static String submitStockOutDetailsTransactionURL = "operationdb-stock-out-6.0.3.php";
    public static String submitYellowCard = "operationdb-yellowcard-details.php";
    public static String submitJointWOrkObservation = "operationdb-joint-work-observation.php";
    public static String submitClassCastUpdation = "operationdb-cust-class-updation.php";
    public static String submitOrderApproval = "operationdb-order-approval-6.0.0.php";
    public static String submitTMApproval = "operationdb-tech-meet-approval-6.0.0.php";
    public static String submitTMStatusUpdate = "operationdb-tech-meet-status-update-6.0.0.php";
    public static String submitInvoiceInformationURL = "operationdb-invoice-generation.php";
    public static String submitCheckOutURL = "operationdb-checkout-6.0.1.php";
    public static String submitLoyaltyTransactionURL = "operationdb-loyalty-6.0.1.php";
    public static String submitRouteURL = "operationdb-route-plan-6.0.5.php";
    public static String submitRoutePlanChangeRequestURL = "operationdb-route-plan-change-request.php";
    public static String submitNewRouteCustURL = "operationdb-route-customer-plan-6.0.0.php";
    public static String submitTourExpURL = "operationdb-tour-expenses-6.0.0.php";
    public static String submitFoodExpURL = "operationdb-food-expenses-6.0.0.php";
    public static String submitLodgeExpURL = "operationdb-lodge-expenses-6.0.0.php";
    public static String submitTourLodgeFoodExpURL_601 = "operationdb-tour-lodge-food-expenses-6.0.4.php";
    public static String submitCRMURL = "operationdb-CRM-transaction.php";
    public static String submitNewBusinessProspectURL = "operationdb-prospectivecustomer-6.0.6.php";
    public static String submitExistingBusinessProspectURL = "operationdb-existing-prospectivecustomer-6.0.2.php";
    public static String submitStockAudittURL = "operationdb-stock-audit-6.0.5.php";
    public static String submitStockReturnURL = "operationdb-stock-return-6.0.1.php";
    public static String submitDoURL = "operationdb-DO-upload.php";
    public static String GETDoNOURL = "DO_dns_no_download.php";
    public static String submitTourAttachmentURL = "operationdb-attachment-export-6.0.0.php";
    public static String submitFreightExpURL = "operationdb-freight-expenses-6.0.0.php";
    public static String submitCashReceiveDepositURL = "operationdb-cash-deposit-receive.php";
    public static String submitMerchandisingTransactionURL = "operationdb-merchandising-6.0.0.php";
    public static String submitTransactionDeletionURL = "transactionDeletion-6.0.0.php";
    public static String submitNewCustomerURL = "operationdb-newcustomer-7.0.1.php";
    public static String submitNewCustomerCustomizeURL = "operationdb-new-customer-customize-6.0.0.php";
    public static String submitOldCustomerURL = "operationdb-newcustomer-6.0.0.php";
    public static String submitOrderStatusURL = "operationdb-order-status.php";
    public static String submitFootSoldierURL = "operationdb-foot-soldier-6.0.1.php";
    public static String submitDeviceInfo = "operationdb-device-information.php";
    public static String submitSurveyRedundantURL = "operationdb-redundant-transaction-6.0.0.php";
    public static String submitCheckInOutURL = "operationdb-check-in-out-6.0.4.php";
    public static String submitMonthlyReportMail = "operationdb-monthly-report-mail.php";
    public static String submitNotesInfoURL = "operationdb-notes-info-6.0.1.php";
    public static String submitNewRouteURL = "operationdb-newroute-6.0.0.php";
    public static String pushAckURL = "operationdb-notification.php";
    public static String tourDaySwappingTransactionURL = "operationdb-tourday-swapping.php";
    public static String attendanceTransactionURL = "operationdb-attendance-6.0.2.php";
    public static String doctorVisitTransactionURL = "operatiodb-doctor-visit-6.0.1.php";
    public static String stockistVisitTransactionURL = "operationdb-stockist-visit-6.0.1.php";
    public static String callDurationTransactionURL = "operationdb-call-duration.php";
    public static String cashDepositTransactionURL = "operationdb-cash-deposit.php";
    public static String cashTransferTransactionURL = "operationdb-cash-transfer.php";
    public static String add_customer_OTP = "add-customer-OTP.php";
    public static String OrderStatusUrl = "https://www.starsaathi.com/SAP/acedns_star_order_details_by_id_for_sfa_v1.php?the_id=";
//    public static String OrderStatusUrl = "https://www.starsaathi.com/SAP/acedns_star_order_details_by_id_v1.php?the_id=";
    public static String DownloadDoMasterStatusUrl = "OTP-DO-download.php";
    public static String doTransactionDisplayFIFOWiseUrl = "DO-transaction-display-fifowise-6.0.0.php";
    public static String downloadPendingBargainUrl = "pending-bargain-download-txt-6.0.0.php";
    public static String mcxBaseOilRateApi = "base-oil-data-download-MCX.php";
    public static String baseOilRateApi = "base-oil-data-download.php";
    public static String RateGenerationApi = "rate-generation-download.php";
    public static String McxRateGenerationApi = "rate-generation-download-MCX.php";
    public static String RatePublishApi = "generate-publish-rate-download.php";
    public static String ReleasedRateDownoadApi = "released-rate-details-download.php";
    public static String RatePublishTransApi = "operatiodb-publish-rate.php";
    public static String giftDeliveryTransaction = "operationdb-gift-delivery-6.0.0.php";
    public static String attendanceCheckoutJourneyInfoTransactionURL = "operationdb-att-checkout-journey-info-6.0.1.php";
    public static String businessProspectCustomizeTransactionURL = "operationdb-business-prospect-customize.php";

    //	laravel apis
    public static String parentURLLaravel = BaseUrl.baseUrl+"reportmvc/api/";
    /*
     * AUTHENTICATION URLs
     */

    public static String RASaudaRateDownload = "v2/RAsaudaratedownload";//encryption decryption done
    public static String RASaudaCounterBidRateDownload = "v2/counterbidratedownload";//encryption decryption done
    public static String RASaudaAcceptedBidRateDownload = "v2/acceptbidratedownload";//encryption decryption done
    public static String RASaudaCounterBidAcceptedBidRateDownload = "v2/counterbidacceptdownload";//encryption decryption done
    public static String RASaudaRejectedBidRateDownload = "v2/rejectbidratedownload";//encryption decryption done
    public static String RAMarginDownload = "v2/margindownload";//encryption decryption done
    public static String RADetentionCostDownload = "v2/detentiondownload";//encryption decryption done
    public static String RARouteFreight = "v2/RAfreightdownloadV1";//encryption decryption done
    public static String RAWindowTimeDownload = "v2/windowtimedownload";//encryption decryption done
    public static String submitNewBidURL = "v2/RAbidrateuploadV2";//encryption decryption done
    public static String submitCounterBidURL = "v2/counterbidstatusupload";//encryption decryption done
    public static String submitTentFormURL = "save-tent-form-details.php";//encryption decryption done
    public static String submitDemoFormURL = "save-demo-form-details.php";
    public static String submitKnockingFormURL = "save-knocking-form-details.php";
    public static String submitTelecallerFormURL = "save-telecaller-form.php";
    public static String submitGroupLeaderFormURL = "save-group-leader-form.php";
    public static String order_summary_pdf = "order_summary_pdf.php";
    public static String operationdb_route_plan_change_approval = "operationdb-route-plan-change-approval.php";
    public static String operationdb_site_lead_change_approval = "operationdb-site-lead-approval.php";
    public static String route_plan_change_request_data = "route-plan-change-request-data-6.0.1.php";
    public static String dsr_summary_pdf = "dsr_pdf_download.php";
    public static String site_lead_conversion_masterURL = "site-lead-conversion-txt-incremental-6.0.1.php";
    public static String complaint_master_masterURL = "complaint-master-txt-incremental-6.0.0.php";
    public static String lead_generation_masterURL = "lead-generation-master-txt-incremental-6.0.0.php";
    public static String quality_complaint_masterURL = "quality_complaint_master-master-txt-incremental-6.0.0.php";
    public static String mtl_testing_masterURL = "mtl_testing_master-master-txt-incremental-6.0.0.php";

    public static String site_lead_download_approvalURL = "site-lead-download-approval.php";
    public static String lead_generation_download_approvalURL = "lead-generation-download-approval.php";
    public static String emp_for_lead_generation_download_approvalURL = "lead-generation-download-approval-emp.php";
    public static String lead_generation_download_detailsUrl = "lead_generation_download_details.php";
    public static String lead_generation_action_updateUrl = "lead_generation_action_update.php";

    public static String kyc_master_txt_incrementalURL = "kyc-master-txt-incremental-6.0.0.php";
    public static String dshboardDataURL = "manager-dashboard-download-6.0.1.php";
    public static String mtl_no_download_detailsURL = "mtl_no_download_details.php";
}
